const container = document.getElementById('container');
const regBtn = document.getElementById('registerBtn');
const signInBtn = document.getElementById('hiddenBtn');

regBtn.addEventListener('click',()=>{
    container.classList.add("active");
});

signInBtn.addEventListener('click',()=>{
    container.classList.remove("active");
});

// Add event listener for sign-up form submission
document.getElementById('signUpForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Capture the input values
    const name = document.getElementById('nameInput').value;
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;

    // Log the captured details to the console
    console.log('Sign-up Details:');
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Password:', password);

    // Store the sign-up details in localStorage
    localStorage.setItem('userName', name);
    localStorage.setItem('userEmail', email);
    localStorage.setItem('userPassword', password);

    // Clear the input fields
    document.getElementById('nameInput').value = '';
    document.getElementById('emailInput').value = '';
    document.getElementById('passwordInput').value = '';

    // Optionally, you can add more logic here, like sending to a server or storing locally
    alert('Sign-up details captured!');
    
});

// Add event listener for sign-in form submission
document.getElementById('signInForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Capture the input values
    const email = document.getElementById('signInEmail').value;
    const password = document.getElementById('signInPassword').value;

    // Retrieve stored details from localStorage
    const storedEmail = localStorage.getItem('userEmail');
    const storedPassword = localStorage.getItem('userPassword');

    // Compare the details
    if (email === storedEmail && password === storedPassword) {
        // If correct, redirect to SignUpPage.html
        location.href = './SignUpPage.html';
    } else {
        // If incorrect, show error
        alert('Invalid email or password. Please try again.');
    }
    document.getElementById('signInEmail').value = '';
});
