//  Date Setup 
document.getElementById("currentDate").textContent = new Date().toLocaleDateString();
document.getElementById("reportDate").textContent = new Date().toLocaleDateString();

//  Sample Supplier Data 
const supplierData = [
  { supplier: "Supplier A", credit: 12000, performance: 85 },
  { supplier: "Supplier B", credit: 8000, performance: 72 },
  { supplier: "Supplier C", credit: 5000, performance: 60 },
  { supplier: "Supplier D", credit: 15000, performance: 92 },
  { supplier: "Supplier E", credit: 3000, performance: 55 }
];

// Table Rendering 
function renderTable(data) {
  const tableBody = document.getElementById("tableBody");
  tableBody.innerHTML = "";

  data.forEach(item => {
    const row = `<tr>
      <td>${item.supplier}</td>
      <td>${item.credit.toLocaleString()}</td>
      <td>${item.performance}%</td>
    </tr>`;
    tableBody.innerHTML += row;
  });
}

//  Charts Setup 
let performanceChart;
let contributionChart;

function renderCharts(data) {
  if (performanceChart) performanceChart.destroy();
  if (contributionChart) contributionChart.destroy();

  const labels = data.map(d => d.supplier);
  const performanceData = data.map(d => d.performance);
  const creditData = data.map(d => d.credit);

  // Bar chart for performance
  const ctx1 = document.getElementById("supplierChart").getContext("2d");
  performanceChart = new Chart(ctx1, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Performance (%)",
        data: performanceData,
        backgroundColor: "#0073e6"
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true, max: 100 }
      }
    }
  });

  // Pie chart for credit contribution
  const ctx2 = document.getElementById("supplierPieChart").getContext("2d");
  contributionChart = new Chart(ctx2, {
    type: "pie",
    data: {
      labels,
      datasets: [{
        data: creditData,
        backgroundColor: ["#0073e6", "#28a745", "#ffc107", "#dc3545", "#6f42c1"]
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom" }
      }
    }
  });
}


// Filters 
document.getElementById("applyFilter").addEventListener("click", () => {
  const supplierFilter = document.getElementById("filterSupplier").value.toLowerCase();
  const creditFilter = parseFloat(document.getElementById("filterCredit").value) || 0;

  const filteredData = supplierData.filter(d =>
    d.supplier.toLowerCase().includes(supplierFilter) && d.credit >= creditFilter
  );

  renderTable(filteredData);
  renderCharts(filteredData);
});

document.getElementById("resetFilter").addEventListener("click", () => {
  document.getElementById("filterSupplier").value = "";
  document.getElementById("filterCredit").value = "";
  renderTable(supplierData);
  renderCharts(supplierData);
});

// Export to Excel 
document.getElementById("downloadBtn").addEventListener("click", () => {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(supplierData);
  XLSX.utils.book_append_sheet(wb, ws, "Suppliers");
  XLSX.writeFile(wb, "Supplier_Report.xlsx");
});

// ================== Export to PDF ==================
document.getElementById("downloadPDFBtn").addEventListener("click", () => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text("Supplier Report", 14, 10);
  doc.autoTable({
    head: [["Supplier", "Credit Limit ($)", "Performance (%)"]],
    body: supplierData.map(d => [d.supplier, d.credit, d.performance])
  });
  doc.save("Supplier_Report.pdf");
});

//  Init
renderTable(supplierData);
renderCharts(supplierData);
