// === Dates ===
document.getElementById("currentDate").textContent = new Date().toLocaleDateString();
let reportDate = new Date();
reportDate.setDate(reportDate.getDate() - 1);
document.getElementById("reportDate").textContent = reportDate.toLocaleDateString();

// === Example Data ===
let salesData = [
  { product: "Product A", units: 120, revenue: 2400, date: "2025-09-01" },
  { product: "Product B", units: 85, revenue: 1700, date: "2025-09-03" },
  { product: "Product C", units: 60, revenue: 1200, date: "2025-09-15" },
  { product: "Product D", units: 200, revenue: 5000, date: "2025-09-05" }
];

let filteredData = [];
let salesChart, lineChart, pieChart;

// === Render Table ===
function renderTable(data) {
  let tbody = document.getElementById("tableBody");
  tbody.innerHTML = "";
  let total = 0;

  data.forEach(item => {
    tbody.innerHTML += `<tr>
      <td>${item.product}</td>
      <td>${item.units}</td>
      <td>${item.revenue}</td>
    </tr>`;
    total += item.revenue;
  });

  document.getElementById("totalRevenue").textContent = "$" + total;
  renderCharts(data);
}

// === Filter by Month ===
function filterByMonth(data, selectedMonth) {
  if (!selectedMonth) {
    document.getElementById("monthDisclaimer").textContent = "Showing all data";
    return data;
  }
  let month = new Date(selectedMonth);
  let year = month.getFullYear();
  let m = month.getMonth();
  let filtered = data.filter(item => {
    let d = new Date(item.date);
    return d.getFullYear() === year && d.getMonth() === m;
  });
  document.getElementById("monthDisclaimer").textContent =
    "Showing data for: " + month.toLocaleString("default", { month: "long", year: "numeric" });
  return filtered;
}

// Initial render: show all data
filteredData = salesData;
renderTable(filteredData);

// === Filters ===
document.getElementById("applyFilter").addEventListener("click", () => {
  let productFilter = document.getElementById("filterProduct").value.toLowerCase();
  let revenueFilter = parseFloat(document.getElementById("filterRevenue").value);
  let monthFilter = document.getElementById("filterMonth").value;

  let tempData = filterByMonth(salesData, monthFilter || null);

  filteredData = tempData.filter(item => {
    let matchesProduct = productFilter ? item.product.toLowerCase().includes(productFilter) : true;
    let matchesRevenue = !isNaN(revenueFilter) ? item.revenue >= revenueFilter : true;
    return matchesProduct && matchesRevenue;
  });

  renderTable(filteredData);
});

document.getElementById("resetFilter").addEventListener("click", () => {
  document.getElementById("filterProduct").value = "";
  document.getElementById("filterRevenue").value = "";
  document.getElementById("filterMonth").value = "";

  filteredData = salesData;
  document.getElementById("monthDisclaimer").textContent = "Showing all data";
  renderTable(filteredData);
});

// === Back Button ===
document.getElementById("backBtn").addEventListener("click", () => {
  window.history.back();
});

// === Excel Export ===
document.getElementById("downloadBtn").addEventListener("click", () => {
  let wb = XLSX.utils.book_new();
  let ws = XLSX.utils.json_to_sheet(filteredData);
  XLSX.utils.book_append_sheet(wb, ws, "Sales Report");
  XLSX.writeFile(wb, "sales_report.xlsx");
});

// === PDF Export ===
document.getElementById("downloadPDFBtn").addEventListener("click", () => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.text("Sales Report", 14, 15);
  doc.autoTable({
    head: [["Product", "Units", "Revenue"]],
    body: filteredData.map(item => [item.product, item.units, item.revenue]),
    startY: 20
  });

  doc.save("sales_report.pdf");
});

// === Render Charts ===
function renderCharts(data) {
  const labels = data.map(item => item.product);
  const revenues = data.map(item => item.revenue / 1000);

  // Bar Chart
  const barCtx = document.getElementById("salesChart").getContext("2d");
  if (salesChart) salesChart.destroy();
  salesChart = new Chart(barCtx, {
    type: "bar",
    data: { labels, datasets: [{ label: "Revenue (k$)", data: revenues, backgroundColor: "#007799" }] },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: v => v + "k" } } } }
  });

  // Line Chart by Month
  const lineCtx = document.getElementById("lineChart").getContext("2d");
  let monthMap = {};
  data.forEach(item => {
    let d = new Date(item.date);
    let key = `${d.getFullYear()}-${d.getMonth() + 1}`;
    monthMap[key] = (monthMap[key] || 0) + item.revenue;
  });
  const monthLabels = Object.keys(monthMap).map(k => {
    let parts = k.split("-");
    return new Date(parts[0], parts[1] - 1).toLocaleString('default', { month: 'short', year: 'numeric' });
  });
  const revenueByMonth = Object.values(monthMap).map(v => v / 1000);
  if (lineChart) lineChart.destroy();
  lineChart = new Chart(lineCtx, {
    type: "line",
    data: { labels: monthLabels, datasets: [{ label: "Revenue (k$)", data: revenueByMonth, borderColor: "#004080", backgroundColor: "rgba(0,64,128,0.2)", fill: true, tension: 0.3 }] },
    options: { responsive: true, plugins: { legend: { display: true } }, scales: { y: { beginAtZero: true, ticks: { callback: v => v + "k" } } } }
  });

  // Pie Chart
  const pieCtx = document.getElementById("pieChart").getContext("2d");
  if (pieChart) pieChart.destroy();
  pieChart = new Chart(pieCtx, {
    type: "pie",
    data: { labels, datasets: [{ data: data.map(item => item.revenue), backgroundColor: ["#007799", "#004080", "#00AAFF", "#00CC88"] }] },
    options: { responsive: true, plugins: { legend: { position: "bottom" } } }
  });
}
